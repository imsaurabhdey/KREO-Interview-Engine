# Interview Assessment Bank v0.2.0-review-remediation: production architecture

**Generated:** 2026-10-29  
**Inventory:** 5,600 technical/conversational prompts across 56 supplied skill labels; 2,000 coding/work-sample assignments across 20 tracks. Each track has exactly 100 challenges with 30 Easy, 40 Moderate and 30 Difficult.  
**Status:** Seed and design pack. All content remains draft until reference answers, executable tests, sources where appropriate, SME review and evaluator calibration pass.

## 1. What changed after the review

- The conversational bank now mixes explanation-with-example, output prediction, misconception correction, artifact reading, debugging, code/design review, trade-offs, experience validation, test strategy, incident leadership, architecture, prioritization, stakeholder conflict and governance scenarios.
- Coding challenges are stored separately from spoken/technical questions. The assessment router recommends coding only where the job description calls for hands-on coding; non-coding roles get work samples, case studies, scenario-based assessment and stakeholder judgment instead of irrelevant algorithm puzzles.
- Each code challenge has a private hidden-test plan (boundary, duplicate/tie, invalid/unauthorized, scale/race, rerun/idempotency). These are **test specifications**, not all executable fixtures yet. The bank explicitly records `runnable_hidden_test_status=plan_only_needs_fixture_compilation`; do not publish a task until a reference solution produces verified fixtures.
- Candidate-facing challenge fields are separated from private judge data. Never pass hidden test inputs, expected outputs, judge notes, reference code or rubric calibration examples into a candidate prompt.

## 2. Inventory and tracks

- Conversational bank: 5600 prompts.
- Coding/work-sample bank: 2000 track assignments, 20 tracks, 100 per track.
- Canonical language algorithms: one common 100-problem catalog assigned to Java, Python, C#/.NET, JavaScript, TypeScript, C++, Swift, Ruby and Kotlin/Android.
- Specialized assessment tracks: React, Angular, Node.js API, SQL, GraphQL, Pandas, PySpark, Salesforce Apex, Playwright Automation, ETL/Data Transformation and DevOps Scripting.
- `skill_assessment_matrix_v2.csv` maps each supplied hiring label to one or more coding tracks or an appropriate non-coding assessment mode. C++ and GraphQL are supplemental tracks because the user explicitly named them but they do not appear as standalone items in the original list. Kotlin is included as a provisional Android technology assumption; validate the actual JD before using it.

## 3. Recommended question record schema

`question_id`, `bank_version`, `category`, `skill_name`, `competency`, `difficulty`, `question_type`, `assessment_type`, `delivery_mode`, `question_text`, `expected_evidence`, `reference_answer_status`, `rubric_id`, `review_status`, `source_policy`, `created_on`, `generation_method`, `reviewer`, `reviewed_at`, `effective_from`, `effective_to`, `source_ids`, `version`, `supersedes_question_id`, `exposure_count`, `leakage_risk`, `validity_evidence`.

For coding tasks, add `coding_question_id`, `track_name`, `track_kind`, `language_or_runtime`, `problem_id`, `problem_statement`, `input_contract`, `output_contract`, `constraints`, `visible_examples`, `hidden_test_plan`, `reference_solution_version`, `runnable_hidden_test_status`, `time_limit`, `memory_limit`, `allowed_libraries`, `starter_code`, `rubric`, `role_mapping`.

## 4. Scoring architecture

Keep three outcomes separate:

1. **Technical/conceptual score:** correctness, reasoning, evidence and trade-offs.
2. **Hands-on task score:** executable correctness, edge cases, complexity/performance and maintainability/security appropriate to the role.
3. **Integrity signal/review:** tool telemetry and policy-defined evidence only. A model's suspicion must not silently lower technical scores. Use an explicit review queue, evidence summary, uncertainty and human review; avoid treating gaze, pauses, accent, disability-related behavior or a single detector output as proof of misconduct.

Within each outcome, use rubric anchors. For example, a 0–4 scale should describe observable evidence for each dimension. The evaluator must cite transcript spans, code lines, test results, or other permitted evidence for every non-trivial score. If evidence is absent, mark `insufficient_evidence` instead of guessing.

## 5. Coding challenge quality gate

A challenge is not production-ready until all are true:

1. The task is job-relevant and difficulty-calibrated.
2. Input/output types, constraints, nullability, ordering/tie policy and complexity expectations are explicit.
3. An independently reviewed reference solution passes visible examples and private tests.
4. Private tests cover edge, adversarial, invalid, scale, and regression classes appropriate to the task.
5. The judge has CPU, memory, wall-clock, process, network and file-system limits appropriate to the language.
6. Tests are mutation-checked: at least some plausible wrong solutions must fail.
7. The task has a solution explanation and rubric, plus approved language/runtime versions.
8. Similarity/leakage checks and exposure counts are recorded; rotate variants after exposure.

The 15 examples in `coding_sample_fixtures_15.jsonl` are starter examples, not a complete judge. Confirm their behavior against a version-controlled reference implementation and add further private tests before release.

## 6. Selecting assessments for a role

Use the job description and seniority, not only the broad skill label. A recommended structure:

- Junior: core fundamentals + one small code/work-sample task; evaluate correctness and ability to explain.
- Mid-level: coding + debugging/review + integration/testing scenario.
- Senior: coding or design work sample + architecture trade-offs + production incident + experience/ownership evidence.
- Lead/manager: architecture and prioritization + stakeholder conflict/mentoring/project outcome evidence; coding only if it is an essential job function.

Do not ask every candidate all 100 questions. Build a calibrated 45–75 minute assessment blueprint with skill weights, difficulty mix, time budgets, follow-up rules and question exposure controls.

## 7. Daily knowledge-base improvement pipeline

1. Ingest approved sources from official docs, release notes, standards, internal runbooks and JDs. Store source URL, fetch date, version, license/permission, checksum and affected skills.
2. Diff against current source records; create proposed deltas instead of overwriting approved knowledge.
3. Generate new question variants, answer keys, citations, rubrics and private test plans in a staging branch.
4. Run schema checks, duplicate/near-duplicate detection, source entailment checks, ambiguity checks, language-level checks and expected-answer consistency checks.
5. Compile coding fixtures by executing a reference solution. Run tests against known-bad/mutated solutions so that tests prove meaningful distinction.
6. Evaluate candidate scoring on a golden set: high/low anchors, acceptable alternate answers, edge cases, multiple accents/transcription errors where relevant, and seniority-specific examples.
7. Route technical changes, rubric changes, and high-impact score changes to a qualified reviewer. Automated checks can recommend approval but must not unilaterally promote hiring criteria.
8. Release versioned snapshots, keep audit logs and rollback capability, then monitor disagreement, appeals, pass-rate changes, item difficulty, subgroup impacts where legally/ethically appropriate, and stale sources.

## 8. Metrics to monitor

- Item difficulty and discrimination, pass rate by job level, completion time, candidate abandonment, interviewer override rate, evaluator disagreement, appeal/false-positive rate, defect leakage, coding-test mutation score, source staleness, duplicate exposure, and adverse-impact indicators where permitted.
- Remove or revise questions that are ambiguous, outdated, leaked, weakly related to job tasks, or have poor discrimination. Do not optimize only for difficulty; a hard question that measures irrelevant trivia is a bad assessment.

## 9. Additional improvements

- Build a competency graph: role → skill → subskill → question → expected evidence → rubric dimension → approved source.
- Create adaptive follow-ups: ask a deeper question only when the prior response provides evidence to probe; avoid changing difficulty unpredictably across candidates.
- Add practical assessment modes: code execution, pull-request review, API debugging, SQL dataset query, ETL reconciliation, browser automation, incident simulation, product/design critique and requirements clarification.
- Add question exposure management: candidate-specific variants, random seeds, retired/leaked states and a cool-down period.
- Use a deterministic evaluator for executable tests; use an LLM only for reasoning not directly reducible to test results. Keep actual hidden-test outputs out of LLM context.
- Maintain a golden dataset of anonymized, consented or synthetic answers and code, rated independently by multiple human reviewers, then calculate agreement and calibration.
- Separate model/provider version changes from question-bank changes so a score shift can be traced to its cause.
- Support accommodations and alternate equivalent formats; validate that timed tests measure job skills rather than typing speed or unrelated barriers.

## 10. Governance and safety references

- NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
- EEOC employment tests and selection procedures (US guidance; apply applicable local law): https://www.eeoc.gov/laws/guidance/employment-tests-and-selection-procedures
- OWASP GenAI/LLM application risks: https://genai.owasp.org/llm-top-10/

These references support risk management, job-related validation and prompt-injection/data-handling controls; they do not replace legal advice or the employer's validation obligations.
